#!/bin/bash
chmod -R +x .

cd apt-transport-https
./install.sh
cd ..

cd ca-certificates
./install.sh
cd ..

cd curl
./install.sh
cd ..

cd software-properties-common
./install.sh
cd ..

cd docker-ce
./install.sh
cd ..

read -p "Input user to add docker group: " user
if [ "$user" = "" ]; then
	echo "user is empty, exit"
	exit
fi

usermod -aG docker $user

read -p "Input docker registry address and port (example 10.15.0.144:5000): " registry_ip
if [ "$registry_ip" = "" ]; then
        echo "input is null, exit"
else
        daemon="{\"insecure-registries\" : [\"$registry_ip\"]}"
        echo "$daemon" > "daemon.json"
fi

cp "daemon.json" "/etc/docker/daemon.json"

read -p "Need logout to complete install (y/n): " choose
if [ "$choose" = "y" ]; then
	service docker restart
	pkill -KILL -u $user
fi
